from lib.pyItunes.XMLLibraryParser import XMLLibraryParser
from lib.pyItunes.Library import Library
from lib.pyItunes.Song import Song