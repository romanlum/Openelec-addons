class Song:
	"""
	Song Attributes:
	name (String)
	artist (String)
	album_arist (String)
	composer = None (String)
	album = None (String)
	genre = None (String)
	kind = None (String)
	size = None (Integer)
	total_time = None (Integer)
	track_number = None (Integer)
	year = None (Integer)
	date_modified = None (Time)
	date_added = None (Time)
	bit_rate = None (Integer)
	sample_rate = None (Integer)
	comments = None (String)
	rating = None (Integer)
	album_rating = None (Integer)
	play_count = None (Integer)
	location = None (String)
	"""
	name = None
	artist = None
	album_arist = None
	composer = None
	album = None
	genre = None
	kind = None
	size = None
	total_time = None
	track_number = None
	year = None
	date_modified = None
	date_added = None
	bit_rate = None
	sample_rate = None
	comments = None
	rating = None
	album_rating = None
	play_count = None
	location = None
	
	#title = property(getTitle,setTitle)