from .main import FileManager

def start():
    return FileManager()

config = []
