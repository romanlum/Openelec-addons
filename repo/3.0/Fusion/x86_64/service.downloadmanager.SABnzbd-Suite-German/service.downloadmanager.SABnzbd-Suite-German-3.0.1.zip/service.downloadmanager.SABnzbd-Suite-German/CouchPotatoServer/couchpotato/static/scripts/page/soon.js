Page.Soon = new Class({

	Extends: PageBase,

	name: 'soon',
	title: 'Which wanted movies are released soon?'

})