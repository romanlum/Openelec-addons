from .main import V1Importer

def start():
    return V1Importer()

config = []
