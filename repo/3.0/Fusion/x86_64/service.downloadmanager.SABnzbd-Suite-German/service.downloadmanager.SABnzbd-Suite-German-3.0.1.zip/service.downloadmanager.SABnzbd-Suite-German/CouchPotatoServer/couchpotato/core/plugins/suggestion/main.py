from couchpotato.core.plugins.base import Plugin

class Suggestion(Plugin):

    pass

