# This file will be patched by setup.py
# The __version__ should be set to the branch name
# (e.g. "trunk" or "0.4.x")

# You MUST use double quotes (so " and not ')

__version__ = "0.7.9"
__baseline__ = "c237ddfef464649ec3713d43c441def6c8656f46"
