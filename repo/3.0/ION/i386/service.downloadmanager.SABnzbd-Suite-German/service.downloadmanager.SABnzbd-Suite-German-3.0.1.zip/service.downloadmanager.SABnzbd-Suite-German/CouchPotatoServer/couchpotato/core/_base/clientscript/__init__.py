from .main import ClientScript

def start():
    return ClientScript()

config = []
