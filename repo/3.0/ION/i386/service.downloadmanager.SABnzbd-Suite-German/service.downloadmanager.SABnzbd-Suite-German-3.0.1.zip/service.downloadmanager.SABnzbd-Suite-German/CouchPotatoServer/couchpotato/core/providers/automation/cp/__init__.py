from .main import CP

def start():
    return CP()

config = []
