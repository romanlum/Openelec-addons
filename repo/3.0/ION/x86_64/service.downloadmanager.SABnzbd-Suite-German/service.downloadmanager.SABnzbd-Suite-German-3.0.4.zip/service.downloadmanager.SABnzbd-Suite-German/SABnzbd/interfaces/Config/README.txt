
uniConfig for SABnzbd 0.7.x
zoggy@sabnzbd.org


========================================================
LIBRARIES USED

jQuery
 * Project repository: https://github.com/jquery/jquery
 * Dual licensed under the MIT and GPL licenses:
 *    http://www.gnu.org/licenses/gpl.html
 *    http://www.opensource.org/licenses/mit-license.php

jQuery UI
 * Project repository: https://github.com/jquery/jquery-ui
 * Dual licensed under the MIT and GPL licenses:
 *    http://www.gnu.org/licenses/gpl.html
 *    http://www.opensource.org/licenses/mit-license.php

jQuery Form Plugin
 * Project repository: https://github.com/malsup/form
 * Dual licensed under the MIT and GPL licenses:
 *    http://www.gnu.org/licenses/gpl.html
 *    http://www.opensource.org/licenses/mit-license.php

jQuery Tools (tabs)
 * Project repository: https://github.com/jquerytools/jquerytools

Formalize
 * Project repository: https://github.com/nathansmith/formalize
 * Dual licensed under the MIT and GPL licenses:
 *    http://www.gnu.org/licenses/gpl.html
 *    http://www.opensource.org/licenses/mit-license.php

normalize.css
 * Project repository: https://github.com/necolas/normalize.css
 * Licensed under public domain

qTip2
 * Project repository: https://github.com/craga89/qtip2
 * Dual licensed under the MIT and GPL licenses:
 *    http://www.gnu.org/licenses/gpl.html
 *    http://www.opensource.org/licenses/mit-license.php


========================================================
IMAGES USED

/images/loading-*.gif
 - source: http://www.AjaxLoad.info

/images/flags/*
 - source: http://www.famfamfam.com/lab/icons/flags/
