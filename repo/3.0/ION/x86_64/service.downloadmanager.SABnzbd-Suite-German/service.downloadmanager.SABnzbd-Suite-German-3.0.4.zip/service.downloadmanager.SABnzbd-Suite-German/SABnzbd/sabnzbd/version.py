# This file will be patched by setup.py
# The __version__ should be set to the branch name
# (e.g. "trunk" or "0.4.x")

# You MUST use double quotes (so " and not ')

__version__ = "0.7.11"
__baseline__ = "a50412a32751f4d1d555020dea20a2da43d6a309"
