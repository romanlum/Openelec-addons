from .main import Scanner

def start():
    return Scanner()

config = []
