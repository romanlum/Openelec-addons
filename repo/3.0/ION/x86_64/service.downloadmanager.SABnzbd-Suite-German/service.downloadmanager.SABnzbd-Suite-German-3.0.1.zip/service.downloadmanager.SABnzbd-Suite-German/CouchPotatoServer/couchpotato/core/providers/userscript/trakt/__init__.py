from .main import Trakt

def start():
    return Trakt()

config = []
