from .main import LibraryPlugin

def start():
    return LibraryPlugin()

config = []
