from .main import Scheduler

def start():
    return Scheduler()

config = []
