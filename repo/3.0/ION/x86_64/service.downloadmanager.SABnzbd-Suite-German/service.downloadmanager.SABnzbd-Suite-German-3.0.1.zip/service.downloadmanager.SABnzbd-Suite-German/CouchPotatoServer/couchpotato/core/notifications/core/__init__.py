from .main import CoreNotifier

def start():
    return CoreNotifier()

config = []
